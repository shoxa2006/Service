const one = document.getElementById('one')
const two = document.getElementById('two')
const three = document.getElementById('three')
const four = document.getElementById('four')

function activeone() {
    one.style.backgroundColor = '#C2E54F'
    two.style.backgroundColor = '#343a400d'
    three.style.backgroundColor = '#343a400d'
    four.style.backgroundColor = '#343a400d'
    one.style.color = '#fff'
    two.style.color = '#212529'
    three.style.color = '#212529'
    four.style.color = '#212529'
}

function activetwo() {
    one.style.backgroundColor = '#343a400d'
    two.style.backgroundColor = '#C2E54F'
    three.style.backgroundColor = '#343a400d'
    four.style.backgroundColor = '#343a400d'
    one.style.color = '#212529'
    two.style.color = '#fff'
    three.style.color = '#212529'
    four.style.color = '#212529'
}

function activethre() {
    one.style.backgroundColor = '#343a400d'
    two.style.backgroundColor = '#343a400d'
    three.style.backgroundColor = '#C2E54F'
    four.style.backgroundColor = '#343a400d'
    one.style.color = '#212529'
    two.style.color = '#212529'
    three.style.color = '#fff'
    four.style.color = '#212529'
}

function activefour() {
    one.style.backgroundColor = '#343a400d'
    two.style.backgroundColor = '#343a400d'
    three.style.backgroundColor = '#343a400d'
    four.style.backgroundColor = '#C2E54F'
    one.style.color = '#212529'
    two.style.color = '#212529'
    three.style.color = '#212529'
    four.style.color = '#fff'
}